package com.example.quizpartyka64036.pakunek;

//pytania i odpowiedzi

public class Pytania {

    String pytanie;
    String opcja1, opcja2, opcja3, opcja4;
    String prawidlowaOdp;

    //konstruktory


    public Pytania(String pytanie, String opcja1, String opcja2, String opcja3, String opcja4, String prawidlowaOdp) {
        this.pytanie = pytanie;
        this.opcja1 = opcja1;
        this.opcja2 = opcja2;
        this.opcja3 = opcja3;
        this.opcja4 = opcja4;
        this.prawidlowaOdp = prawidlowaOdp;
    }

    //gettery i settery

    public String getPytanie() {
        return pytanie;
    }

    public void setPytanie(String pytanie) {
        this.pytanie = pytanie;
    }

    public String getOpcja1() {
        return opcja1;
    }

    public void setOpcja1(String opcja1) {
        this.opcja1 = opcja1;
    }

    public String getOpcja2() {
        return opcja2;
    }

    public void setOpcja2(String opcja2) {
        this.opcja2 = opcja2;
    }

    public String getOpcja3() {
        return opcja3;
    }

    public void setOpcja3(String opcja3) {
        this.opcja3 = opcja3;
    }

    public String getOpcja4() {
        return opcja4;
    }

    public void setOpcja4(String opcja4) {
        this.opcja4 = opcja4;
    }

    public String getPrawidlowaOdp() {
        return prawidlowaOdp;
    }

    public void setPrawidlowaOdp(String prawidlowaOdp) {
        this.prawidlowaOdp = prawidlowaOdp;
    }
}