package com.example.quizpartyka64036.pakunek2;
import android.os.CountDownTimer;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizpartyka64036.R;
import com.example.quizpartyka64036.pakunek.Pytania;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    TextView licznikPytan, stoper, pytanie;

    Button btOpcja1, btOpcja2, btOpcja3, btOpcja4;

    //lista na pytania
    ArrayList<Pytania> listaPytan = new ArrayList<>();

    int licznik = 0;

    CountDownTimer tm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //przypisanie do zmiennej metody, która zwraca widok
        pytanie = findViewById(R.id.pytanie);
        licznikPytan = findViewById(R.id.licznikPytan);
        stoper = findViewById(R.id.stoper);

        btOpcja1 = findViewById(R.id.btOpcja1);
        btOpcja2 = findViewById(R.id.btOpcja2);
        btOpcja3 = findViewById(R.id.btOpcja3);
        btOpcja4 = findViewById(R.id.btOpcja4);

        //dodanie pytań do tabeli listaPytan
        listaPytan.add(new Pytania("Kiedy był chrzest Polski?", "2019", "966",
                "212", "1410", "966"));
        listaPytan.add(new Pytania("W jakim województwie znajduje się Warszawa?", "Dolnośląskie", "Mazowieckie",
                "Łódzkie", "Lubelskie", "Mazowieckie"));
        listaPytan.add(new Pytania("Która planeta jest najbliżej Słońca?", "Ziemia", "Merkury",
                "Neptun", "Mars", "Merkury"));
        //inicjalizacja stopera
        licznik = 0;

        //załadowanie pytania i odpowiedzi na nie
        zaladujPytanie(licznik);

        stoper.setText("10");
        //odmierzacz czasu
        tm = new CountDownTimer(10 * 1000, 1000) {
            @Override
            public void onTick(long czasDoKonca) {
                stoper.setText("" + czasDoKonca / 1000);
            }
            //metoda na zakończenie quizu
            @Override
            public void onFinish() {

                Toast.makeText(MainActivity.this, "Koniec!", Toast.LENGTH_SHORT).show();
            }
        };


    }
    //załadowanie pytania
    public void zaladujPytanie(int n) {

        final Pytania q = listaPytan.get(n);

        licznikPytan.setText((n + 1) + "/" + listaPytan.size());

        stoper.setText("" + 12);
        if (tm != null) {
            tm.start();
        }
        //pobieranie wartości pytań
        pytanie.setText("#" + (n + 1) + " " + q.getPytanie());
        btOpcja1.setText("" + q.getOpcja1());
        btOpcja2.setText("" + q.getOpcja2());
        btOpcja3.setText("" + q.getOpcja3());
        btOpcja4.setText("" + q.getOpcja4());

        btOpcja1.setOnClickListener(v -> {
        //kod który pokazuje co ma się stać jeśli klikniemy w którąś z opcji - czy nasza odpowiedź jest prawidłowa lub nie oraz pokazanie kolejnego pytania
            if (btOpcja1.getText().equals(q.getPrawidlowaOdp())) {
                Toast.makeText(MainActivity.this, "Prawidłowa odpowiedź", Toast.LENGTH_SHORT).show();

                if (licznik < (listaPytan.size() - 1)) {
                    tm.cancel();
                    licznik++;
                    zaladujPytanie(licznik);
                } else {
                    Toast.makeText(MainActivity.this, "Udało Ci się odpowiedzieć na wszystkie pytania!", Toast.LENGTH_SHORT).show();
                }


            } else {
                Toast.makeText(MainActivity.this, "Zła odpowiedź", Toast.LENGTH_SHORT).show();
            }


        });

        //przycisk 2
        btOpcja2.setOnClickListener(v -> {

            if (btOpcja2.getText().equals(q.getPrawidlowaOdp())) {

                Toast.makeText(MainActivity.this, "Prawidłowa odpowiedź", Toast.LENGTH_SHORT).show();

                if (licznik < (listaPytan.size() - 1)) {
                    tm.cancel();
                    licznik++;
                    zaladujPytanie(licznik);
                } else {
                    Toast.makeText(MainActivity.this, "Udało Ci się odpowiedzieć na wszystkie pytania!", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(MainActivity.this, "Zła odpowiedź", Toast.LENGTH_SHORT).show();
            }

        });

        //przycisk 3
        btOpcja3.setOnClickListener(v -> {

            if (btOpcja3.getText().equals(q.getPrawidlowaOdp())) {

                Toast.makeText(MainActivity.this, "Dobra odpowiedź", Toast.LENGTH_SHORT).show();
                if (licznik < (listaPytan.size() - 1)) {
                    tm.cancel();
                    licznik++;
                    zaladujPytanie(licznik);
                } else {
                    Toast.makeText(MainActivity.this, "Udało Ci się odpowiedzieć na wszystkie pytania!", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(MainActivity.this, "Zła odpowiedź", Toast.LENGTH_SHORT).show();
            }

        });

        //przycisk 4
        btOpcja4.setOnClickListener(v -> {

            if (btOpcja4.getText().equals(q.getPrawidlowaOdp())) {

                Toast.makeText(MainActivity.this, "Dobra odpowiedź", Toast.LENGTH_SHORT).show();
                if (licznik < (listaPytan.size() - 1)) {
                    tm.cancel();
                    licznik++;
                    zaladujPytanie(licznik);
                } else {
                    Toast.makeText(MainActivity.this, "Udało Ci się odpowiedzieć na wszystkie pytania!", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(MainActivity.this, "Zła odpowiedź", Toast.LENGTH_SHORT).show();
            }

        });
    }
}
